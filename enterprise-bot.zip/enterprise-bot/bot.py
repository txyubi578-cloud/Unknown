import os
import asyncio
from fastapi import FastAPI
from telethon import TelegramClient, events

app = FastAPI()

# Bot configuration
API_ID = int(os.getenv('TELEGRAM_API_ID', '0'))
API_HASH = os.getenv('TELEGRAM_API_HASH', '')
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')

client = TelegramClient("vercel_bot", API_ID, API_HASH)

@app.get("/")
async def home():
    return {"message": "Bot is running on Vercel!"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

# Telegram bot handlers
@client.on(events.NewMessage(pattern='/start'))
async def start_handler(event):
    await event.reply("""
🤖 **မင်္ဂလာပါ! Vercel Bot ပါ**

ဒီ Bot က Vercel ပေါ်မှာ Run နေပါတယ်
အောက်က Commands တွေသုံးလို့ရပါတယ်:

/start - Bot အကြောင်း
/help - အကူအညီ
/ping - စစ်ဆေးမှု
/time - အချိန်ကြည့်ရန်
    """)

@client.on(events.NewMessage(pattern='/help'))
async def help_handler(event):
    await event.reply("""
🎯 **အသုံးပြုနည်းများ:**

/start - Bot အကြောင်း
/help - အကူအညီ
/ping - Bot အလုပ်လုပ်မလုပ်စစ်ဆေးရန်
/time - လက်ရှိအချိန်ကြည့်ရန်

🌤️ **ရာသီဥတု:**
/weather မြို့အမည်

👑 **Admin Commands:**
/add @username nickname
/list - စာရင်းကြည့်ရန်
/tagall - အားလုံးကိုခေါ်ရန်
    """)

@client.on(events.NewMessage(pattern='/ping'))
async def ping_handler(event):
    await event.reply("🏓 **Pong!**\nBot is alive and running!")

@client.on(events.NewMessage(pattern='/time'))
async def time_handler(event):
    from datetime import datetime
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    await event.reply(f"🕒 **လက်ရှိအချိန်:**\n{current_time}")

@client.on(events.NewMessage(pattern='/weather'))
async def weather_handler(event):
    try:
        city = event.text.split(maxsplit=1)[1] if ' ' in event.text else "ရန်ကုန်"
        await event.reply(f"🌤️ {city} မြို့ရဲ့ ရာသီဥတုကို ကြည့်ရန် ပြင်ဆင်နေပါသည်...")
    except:
        await event.reply("❌ မြို့အမည်ထည့်ပေးပါ\nဥပမာ: /weather ရန်ကုန်")

# Bot start function
async def start_bot():
    await client.start(bot_token=BOT_TOKEN)
    print("✅ Bot started on Vercel!")

# FastAPI startup event
@app.on_event("startup")
async def startup():
    asyncio.create_task(start_bot())

# For Vercel
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)